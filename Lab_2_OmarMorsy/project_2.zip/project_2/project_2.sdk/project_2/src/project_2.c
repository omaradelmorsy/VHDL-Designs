#include <stdio.h>
#include <stdint.h>

int main(void)
{
    uint32_t *regmap = (uint32_t *)0x70000000;
    size_t R;

    // Test Case 1: Logic AND Operation
    regmap[0] = 0xAAAAAAAA;     // A input -> REG0_OUT
    regmap[1] = 0xCCCCCCCC;     // B input -> REG1_OUT
    regmap[5] = 0x0000;         // ALUOp -> REG5_OUT
    regmap[6] = 0x00;           // SHAMT -> REG6_OUT
    R = regmap[0];              // R output <- REG0_IN
    printf("0x%08X AND 0x%08X = 0x%08zX (%s)\n",
           0xAAAAAAAA, 0xCCCCCCCC, R, (R == (size_t)0x88888888) ? "COR" : "ERR");

    // Test Case 2: Logic OR Operation
    regmap[0] = 0xAAAAAAAA;     // A input -> REG0_OUT
    regmap[1] = 0xCCCCCCCC;     // B input -> REG1_OUT
    regmap[5] = 0x0001;         // ALUOp -> REG5_OUT
    regmap[6] = 0x00;           // SHAMT -> REG6_OUT
    R = regmap[0];              // R output <- REG0_IN
    printf("0x%08X OR  0x%08X = 0x%08zX (%s)\n",
           0xAAAAAAAA, 0xCCCCCCCC, R, (R == (size_t)0xEEEEEEEE) ? "COR" : "ERR");

    // Test Case 3: Logic XOR Operation
    regmap[0] = 0xAAAAAAAA;     // A input -> REG0_OUT
    regmap[1] = 0xCCCCCCCC;     // B input -> REG1_OUT
    regmap[5] = 0x0002;         // ALUOp -> REG5_OUT
    regmap[6] = 0x00;           // SHAMT -> REG6_OUT
    R = regmap[0];              // R output <- REG0_IN
    printf("0x%08X XOR 0x%08X = 0x%08zX (%s)\n",
           0xAAAAAAAA, 0xCCCCCCCC, R, (R == (size_t)0x66666666) ? "COR" : "ERR");

    // Test Case 4: Arithmetic ADD Operation
    regmap[0] = 5;              // A input -> REG0_OUT
    regmap[1] = 3;              // B input -> REG1_OUT
    regmap[5] = 0x0004;         // ALUOp -> REG5_OUT
    regmap[6] = 0x00;           // SHAMT -> REG6_OUT
    R = regmap[0];              // R output <- REG0_IN
    printf("%2zu + %2zu = %3zu (%s)\n",
           (size_t)5, (size_t)3, R, (R == (size_t)8) ? "COR" : "ERR");

    // Test Case 5: Arithmetic SUB Operation
    regmap[0] = 8;              // A input -> REG0_OUT
    regmap[1] = 3;              // B input -> REG1_OUT
    regmap[5] = 0x0006;         // ALUOp -> REG5_OUT
    regmap[6] = 0x00;           // SHAMT -> REG6_OUT
    R = regmap[0];              // R output <- REG0_IN
    printf("%2zu - %2zu = %3zu (%s)\n",
           (size_t)8, (size_t)3, R, (R == (size_t)5) ? "COR" : "ERR");

    // Test Case 6: SUB with Zero Result
    regmap[0] = 55555;          // A input -> REG0_OUT
    regmap[1] = 55555;          // B input -> REG1_OUT
    regmap[5] = 0x0006;         // ALUOp -> REG5_OUT
    regmap[6] = 0x00;           // SHAMT -> REG6_OUT
    R = regmap[0];              // R output <- REG0_IN
    printf("%2zu - %2zu = %3zu (%s)\n",
           (size_t)55555, (size_t)55555, R, (R == 0) ? "COR" : "ERR");

    // Test Case 7: Comparison SLT Operation
    regmap[0] = 3;              // A input -> REG0_OUT
    regmap[1] = 5;              // B input -> REG1_OUT
    regmap[5] = 0x000A;         // ALUOp -> REG5_OUT
    regmap[6] = 0x00;           // SHAMT -> REG6_OUT
    R = regmap[0];              // R output <- REG0_IN
    printf("%2zu < %2zu = %3zu (%s)\n",
           (size_t)3, (size_t)5, R, (R == (size_t)1) ? "COR" : "ERR");

    // Test Case 8: Shift Left Logical
    regmap[0] = 0xFEDCBA98;     // A input -> REG0_OUT
    regmap[1] = 0x00000000;     // B input -> REG1_OUT
    regmap[5] = 0x000C;         // ALUOp -> REG5_OUT
    regmap[6] = 0x01;           // SHAMT -> REG6_OUT
    R = regmap[0];              // R output <- REG0_IN
    printf("0x%08X << 1 = 0x%08zX (%s)\n",
           0xFEDCBA98, R, (R == (size_t)0xFDB97530) ? "COR" : "ERR");

    // Test Case 9: Shift Right Logical
    regmap[0] = 0xFEDCBA98;     // A input -> REG0_OUT
    regmap[1] = 0x00000000;     // B input -> REG1_OUT
    regmap[5] = 0x000E;         // ALUOp -> REG5_OUT
    regmap[6] = 0x01;           // SHAMT -> REG6_OUT
    R = regmap[0];              // R output <- REG0_IN
    printf("0x%08X >> 1 = 0x%08zX (%s)\n",
           0xFEDCBA98, R, (R == (size_t)0x7F6E5D4C) ? "COR" : "ERR");

    return 0;
}
